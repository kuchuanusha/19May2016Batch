package com.flp.fms.service;
import com.flp.fms.domain.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import com.flp.ems.domain.Film;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements IFilmService {
	
	
	IFilmDao filmDao;
	
	public FilmServiceImpl() 
	{
	
		filmDao=new FilmDaoImplForList();
	}
	public void addFilm(List film) throws ParseException(){
		
		filmDao.addFilm(film);
		
	}
	
	public void modifyFilm()
	{
		
		
	}

 
	public boolean removeFilm(int film_id){
	 return filmDao.removeFilm(film_id);
    }
	
	public Film searchFilm(int film_id){
		return filmDao.searchFilm(film_id);
	}
 
	public List<Film> getAllFilms(){
		return filmDao.getAllFilms();
		
	}
	
}
