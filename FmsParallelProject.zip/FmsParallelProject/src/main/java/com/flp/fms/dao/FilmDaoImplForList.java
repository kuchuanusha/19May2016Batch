package com.flp.fms.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.flp.fms.domain.*;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.flp.fms.service.Film;
import com.flp.fms.service.FilmDaoImplForList;
import com.flp.fms.Exceptions;
public class FilmDaoImplForList implements IFilmDao {
	
	protected EntityManager em;

	
	public FilmDaoImplForList(EntityManager em) 
	{
		this.em=em;
		
	}
	public void addFilm(Film film) throws ParseException(){
		
		em.persist(film);
		
	}
	
	public void modifyFilm()
	{
		
		
	}

 
	public boolean removeFilm(int film_id){
		Film film=searchFilm(film_id);
		if(film!=null)
		{
			em.remove(film);
			return true;
		}
		else
			return false;
    }
	
	public Film searchFilm(int film_id){
		return em.find(Film.class, film_id);
		
	}
 
	public List<Film> getAllFilms(){
		
		TypedQuery<Film> query = em.createQuery("Select f from Film f",Film.class);
		return query.getResultList();
	}

}
