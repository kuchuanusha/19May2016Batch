package com.flp.fms.dao;



import java.util.List;

import com.flp.fms.domain.*;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;



public class ActorDaoImplForList implements IActorDao {
	
	protected EntityManager em;

	
	public ActorDaoImplForList(EntityManager em) 
	{
		this.em=em;
		
	}
	public Actor addActor(String first_name,String last_name)
	{
		Actor actor=findActorByName(first_name);
		if(actor == null)
		{
			actor=new Actor(first_name,last_name);
		}
		em.persist(actor);
		return actor;
	}
	
	public void modifyActor()
	{
		
		
	}

 
	public boolean removeActor(int actor_id){
		Actor actor=searchActor(actor_id);
		if(actor!=null)
		{
			em.remove(actor);
			return true;
		}
		else
			return false;
    }
	public Actor findActorByName(String first_name){
		return em.find(Actor.class, first_name);
	}
	
	public Actor searchActor(int actor_id){
		return em.find(Actor.class, actor_id);
		
	}
 
	public List<Actor> getAllActors(){
		
		TypedQuery<Actor> query = em.createQuery("Select actor from Actor actor",Actor.class);
		return query.getResultList();
	}
	

	
	

}
