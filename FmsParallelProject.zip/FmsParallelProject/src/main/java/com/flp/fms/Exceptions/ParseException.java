package com.flp.fms.Exceptions;

public class ParseException extends Exception {

}
